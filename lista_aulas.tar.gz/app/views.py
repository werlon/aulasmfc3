from django.shortcuts import render

# Create your views here.
from app.models import Aulas

def maratona(request):
    aulas = Aulas.objects.all()
    return render(
        request,
        'maratona.html',
        {
            'aulas': aulas
        }
    )